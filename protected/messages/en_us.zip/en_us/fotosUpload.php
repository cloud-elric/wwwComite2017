<?php
return array (
		'concursarBtn'=>'Submit to contest',
		'mensajeFinalizacion' => 'Your photos are now ready to be reviewed by our Judges - Good luck!',
		'header'=>'Upload<span>yourPhotos</span>',
		'needHelp'=>'Need Assistance',
		'headerModal'=>'Warning',
		'warningMessage'=>'If you continue you won\'t be able to edit your photos or upload different ones are you sure these photos are final',
		'cancelBtn'=>'Let me take another look',
		'successBtn'=>'I\'m certain these photos are final',
		'loadImage'=>'Uploading image',
		'browserNoSupport'=>'These browser isn\'t supported',
		'fileInvalid'=>'Formato de archivo inválido',
		'completed'=>'Completed',
		'messageWait'=>'Preparando thumbnail espere un momento',
		'errorMessage'=>'Ocurrio un problema al guardar la imagen'
);