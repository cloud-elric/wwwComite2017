<?php
return array(
		'header'=>'Receipt summary',
		'headerCupon'=>'Cupons',
		'addCupon'=>'Add cupon',
		'placeholderCupon'=>'Cupon Code',
		'cuponNoExite'=>'Cupon Code no validate',
		'headerTipoPago'=>'Payment Gateway',
		'totalAntesDeImpuesto'=>'Total before tax',
		'impuesto'=>'Tax',
		'total'=>'Total',
		'submit'=>'Make payment',
		'warningPay'=>'You must select a payment gateway'
		
		
);