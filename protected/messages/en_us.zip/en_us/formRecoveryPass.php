<?php
return array(
	'instrucciones'=>'In order to retrieve your password please provide us with your registration e-mail',
	'submit'=>'Retrieve Password',
	'messageError'=>"El correo ingresado no se encuentra registrado",
		'successMessageSendPass'=>'Te hemos enviado un correo',
		
);