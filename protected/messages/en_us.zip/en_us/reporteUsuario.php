<?php
return array(
		'user'=>'The user: ',
		'mail'=>' With email:',
		'instruccionProblema'=>' Has the following issue: ',
		'instruccionProblemaOcaciono'=>' Problem description is: ',
);