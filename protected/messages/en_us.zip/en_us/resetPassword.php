<?php
return array(
		'successMessage'=>'La contraseña ha sido cambiada exitosamente',
		'errorMessage'=>'Ocurrió un problema al momento de guardar los datos',
		'errorMessageRequest'=>'La solicitud para recuperar contraseña ha expirado',
		'instrucciones'=>'Por favor ingresa una nueva contraseña',
		'placeholderPass'>='Contraseña',
		'placeholderPassRepeat'>='Repetir contraseña',
		'submit'=>'Cambiar',
		'errorMessage'=>'No se ingreso datos o las contraseñas no son iguales.',
);