<?php
return array(
		'gretting'=>'Forgot your password?',
		'descriptionMessage1'=>'We just got a request telling us that this account needs a password reset, to reset this password please click on the following ',
		'linkText'=>'link:',
		'btnText'=>'Reset my password',
		'descriptionMessage2'=>'If you didn’t ask for a password reset, please disregard this email, this link will expire on 24hrs',
		'subject'=>'Password  Reset'
);