<?php
return array(
		'username'=>'E-mail',
		'password'=>'Password',
		'rememberMe'=>'Remember Me',
);